#!/bin/bash

PASS="password"

for ((;;))
do

index=0
NODES=()
while read line; do
    NODES[$index]="$line"
    index=$(($index+1))
done < ~/rpc.txt

IDX=$(shuf -i 0-$((${#NODES[@]}-1)) -n 1)

ADDR=game1a9kfnkpwk4a8y05gh7cej6cl728eylp5d42cw4
#NODE=http://127.0.0.1:26657
NODE=${NODES[$IDX]}
CHECK_NODE=$(curl -s $NODE/status | jq .result.sync_info.catching_up)
if [[ $CHECK_NODE != false ]]
then
  continue
fi

SEC=$(nibirud q account $ADDR --node $NODE | jq -r .sequence)
SEC_LAST=$SEC


echo "sending txs seq from $SEC to $((SEC+1000)) with $NODE"
for (( i=$SEC;i<=((SEC+1000));i++ ))
do
 echo $PASS | nibirud tx broadcast ~/txs/$i.json -y --node $NODE &> log.json
 if [[ $(cat log.json | grep "Error:") ]]
 then
   break
 fi
 
 CODE=$(cat log.json | jq .code)
 if [ $CODE == 13 ]
 then
   echo "too big fee"
   break
 fi
 if [ $CODE == 32 ] || [ $CODE == "" ]
 then
   echo "breaking on seq $i with code $CODE"
   break
 fi
done
SEC_LAST=$i

echo "checking txs from $SEC to $SEC_LAST"

for (( i=1;i<=10;i++ ))
do
  SEC1=$(nibirud q account $ADDR --node $NODE | jq -r .sequence)
  if (( $SEC1 >= ((SEC_LAST-50)) ))
  then
    echo "old seq: $SEC, new seq: $SEC1"
    echo "done"
    break
  else
    echo "old seq: $SEC, new seq: $SEC1"
  fi
  sleep 6
done

done
