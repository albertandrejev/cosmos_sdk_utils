#!/bin/bash

mkdir txs
PASS="password"
ACCOUNT="account"
ADDR=game1a9kfnkpwk4a8y05gh7cej6cl728eylp5d42cw4
ACC=$(nibirud q account $ADDR | jq -r .account_number)
SEC=0

nibirud tx bank send $ADDR $ADDR 1ugame --fees 200ugame --generate-only > tx.json

for (( i=$SEC;i<=((SEC+1000000));i++ ))
do
  echo "generating txs seq $i"
  echo $PASS | nibirud tx sign tx.json -s $i -a $ACC --offline --from $ACCOUNT --chain-id neuron-1 --output-document ~/txs/$i.json
done
